# PROMPT PARA O CLAUDE.AI — Infraestrutura Online do DataQuest (GitHub + Supabase + Vercel)

> Cole este texto inteiro no Claude.ai. O prompt é autocontido: descreve o sistema, define regras rígidas de compatibilidade e lista TODOS os entregáveis (estrutura de repositório, banco completo com todas as queries, RLS, storage, deploy na Vercel e arquivos de configuração). Ele não inventa funcionalidades novas — apenas disponibiliza online aquilo que já existe no código.

---

Você é um arquiteto de software full-stack sênior, especialista em React 19, Vite 6, TypeScript 5.8, Supabase (Postgres + Auth + RLS + Storage), Express e Vercel. Vou descrever um sistema existente chamado **DataQuest**. A sua tarefa é transformar esse sistema em uma aplicação **completamente online e persistente**, montando a infraestrutura em **GitHub**, **Supabase** e **Vercel**, seguindo fielmente a estrutura já existente. Você NÃO deve criar funcionalidades novas, NÃO deve renomear entidades, NÃO deve alterar a lógica de negócio dos componentes. Seu trabalho é dar vida ao que já existe.

Execute tudo em etapas e me mostre o código completo de cada arquivo gerado.

---

## 1. CONTEXTO DO SISTEMA (DataQuest)

O **DataQuest** é um Sistema de Gestão de Pesquisas (questionários de campo). Atualmente é um app frontend React/Vite/TS com um backend Express que usa um repositório em memória e sincronização offline via IndexedDB. O objetivo é substituir a persistência em memória/local por uma infraestrutura real em nuvem.

### Stack atual (NÃO mudar):
- **Frontend:** React 19, TypeScript, Vite 6, Tailwind CSS 4, Recharts, lucide-react, jspdf (exportação PDF), motion.
- **Backend:** Node + Express (`server.ts`) servindo as rotas `/api/*` e integrando com o Vite em dev.
- **Persistência local:** IndexedDB (`src/utils/indexedDBStorage.ts`) com store de pesquisas offline, rascunho atual e logs de sincronização.
- **Nuvem já prevista:** `@supabase/supabase-js` — o serviço `src/services/supabaseSyncService.ts` já faz `upsert` na tabela **`pesquisas`**.
- **IA:** Google Gemini (`@google/genai`) usado no backend.

### Módulos existentes (PRESERVAR todos, sem criar novos):
1. **Home / Dashboard** — painéis superiores e conexões recentes.
2. **Pesquisas (Surveys)** — lista, criação via Wizard com lógica condicional, edição, replicação, desativação, exclusão, controle de versão, coletas web (pública/interna), visualização de inativas/excluídas.
3. **Coleta de Respostas (InterviewSubmissions)** — entrevistas com respostas, geolocalização, gravação de áudio, histórico de edição, alteração/exclusão com permissão.
4. **Análise de Resultados (Analytics)** — painéis em tempo real.
5. **Metas (Targets)** — metas por pergunta e **Metas Globais por Demografia** (idade/sexo/bairro), com atribuição de cotas a pesquisadores.
6. **Importação Externa** — importação de planilha, exclusão, acesso.
7. **Cadastro de Colaboradores** — perfis de acesso com permissões granulares (AccessPolicyPermissions), alteração de senha, desativação, edição, inclusão.
8. **Políticas de Acesso** — perfis com permissões.
9. **Histórico de Ações (Auditoria)** — trilha de auditoria com hash de integridade, status de conformidade, exportação CSV/JSON.
10. **Simulador de Coleta** — simulação de entrevistas.
11. **Sincronização Offline** — fila offline e sincronização em lote.
12. **Autenticação com 2FA** — modal de dois fatores.
13. **Sincronização com o Servidor Central** — fluxo de pré-sincronização obrigatória com token para pesquisas em andamento (rotas `/api/surveys/:id/sync`).

### Rotas de API atuais (o backend Express em `server.ts` expõe):
- `GET /api/health` — healthcheck.
- `GET /api/surveys` — listar pesquisas.
- `GET /api/surveys/:id` — obter pesquisa.
- `POST /api/surveys/:id/sync` — sincronização prévia obrigatória (emite token `SYNC-AUTH-...` válido por 15 min).
- `PUT /api/surveys/:id` — subir alterações (exige token quando a pesquisa está em andamento; erro `428 / SYNC_REQUIRED_BEFORE_UPLOAD` se não sincronizou).
- `POST /api/surveys` — criar pesquisa.

---

## 2. REGRAS OBRIGATÓRIAS (NÃO NEGOCIÁVEIS)

1. **NÃO criar funcionalidades novas.** Manter exatamente os módulos, telas, componentes e a lógica de negócio atuais.
2. **NÃO renomear nada** que já existe: tabelas, colunas, campos TS, nomes de componentes, variáveis de ambiente.
3. **Compatibilidade total com o código TypeScript** descrito abaixo. Os serviços frontend continuam chamando os mesmos campos (`survey.id`, `survey.codigo`, `survey.nome`, `status`, `cicloAtual`, `versao`, `atualizadaEm`, etc.) e a mesma tabela `pesquisas`.
4. **Preservar o contrato da API** usada pelo frontend (`src/services/serverSurveyService.ts` e `src/services/supabaseSyncService.ts`): os mesmos endpoints `/api/*`, mesmos códigos de erro (`428`, `SYNC_REQUIRED_BEFORE_UPLOAD`), mesmo formato de resposta (`{ success, survey, message, ... }`).
5. **Mapeamento snake_case ⇄ camelCase** consistente: nas tabelas use `snake_case`; nos tipos TypeScript continue `camelCase`. Os serviços de banco fazem a conversão, mas mantêm os nomes semânticos atuais.
6. **Segurança:** usar apenas variáveis de ambiente para segredos. Nunca hardcodar chaves. O `.env.example` deve documentar todas.
7. Usar **RLS (Row Level Security)** no Supabase, habilitada em todas as tabelas, com políticas coerentes com o modelo de login do app (login/senha por colaborador).
8. Entregar **todas as queries** (DDL de criação, CRUD, consultas analíticas de metas/coletas/dashboard, funções utilitárias) em um único arquivo SQL executável no SQL Editor do Supabase, bem comentado e idempotente (uso de `CREATE TABLE IF NOT EXISTS` e `DROP ... IF EXISTS` só quando necessário).

---

## 3. MODELO DE DADOS (TIPOS EXISTENTES — base para o schema)

Modele as tabelas do Supabase EXATAMENTE a partir destes tipos. Onde o tipo tiver objetos aninhados, use `jsonb`.

### `Survey` (tabela `pesquisas`)
```ts
interface Survey {
  id: string;            // PK (ex: 'pesq_literarraial_2025')
  codigo: string;        // ex: 'LIT-2025-01'
  nome: string;
  descricao: string;
  status: 'ativa' | 'inativa' | 'excluida';
  habilitarColetaWeb: boolean;
  tipoColetaWeb: 'publico' | 'interno';
  colaboradorWebId?: string;
  perguntas: Question[];           // jsonb
  regras: ConditionalRule[];       // jsonb
  metas: MetaTarget[];             // jsonb
  metasGlobais?: GlobalDemographicTarget[]; // jsonb
  pesquisadoresIds: string[];
  cicloAtual: number;
  versao: number;
  criadaEm: string;
  atualizadaEm: string;
  emAndamento?: boolean;
  serverVersion?: number;
  serverSyncToken?: string;
  lastServerSyncAt?: string;
  serverSyncStatus?: 'sincronizado' | 'necessita_sincronizacao' | 'sincronizando' | 'autorizado_para_subir' | 'erro_conflito';
  totalEntrevistasColetadas?: number;
}
```
> O `supabaseSyncService.ts` já faz `upsert(..., { onConflict: 'id' })` com as colunas: `id, codigo, nome, descricao, status, ciclo_atual, versao, dados_completos, atualizada_em`. Garanta que essas colunas existam. `dados_completos` guarda o objeto `Survey` inteiro em `jsonb`.

### `Collaborator` (tabela `colaboradores`)
```ts
interface Collaborator {
  id: string;              // PK
  cpf: string;             // unique
  nome: string;
  rg?: string;
  dataNascimento?: string; // date
  sexo?: 'M' | 'F' | 'Outro' | '';
  login: string;           // unique
  senha?: string;          // hash
  perfilAcessoId: string;  // FK -> perfis_acesso
  email: string;
  celular?: string;
  nomeContatoCelular?: string;
  telefoneFixo?: string;
  nomeContatoFixo?: string;
  ativo: boolean;
  pesquisasVinculadasIds: string[];
  criadoEm: string;
}
```

### `AccessProfile` (tabela `perfis_acesso`)
```ts
interface AccessProfile {
  id: string;          // PK
  name: string;
  description: string;
  permissions: AccessPolicyPermissions; // jsonb — veja o objeto completo abaixo
}
```
`AccessPolicyPermissions` (guarde como `permissions jsonb`):
- Colaboradores: `colaboradores_alterar_senha`, `colaboradores_desativar`, `colaboradores_editar`, `colaboradores_acesso`, `colaboradores_incluir`.
- Análise: `analise_acesso`, `analise_criar_alterar_excluir_resposta`.
- Importação: `importacao_importar_planilha`, `importacao_excluir`, `importacao_acesso`.
- Meta: `meta_criar_alterar_excluir`, `meta_acesso`.
- Pesquisa: `pesquisa_visualizar_excluidas`, `pesquisa_acesso`, `pesquisa_criar`, `pesquisa_alterar`, `pesquisa_excluir`, `pesquisa_ouvir_audio`, `pesquisa_visualizar_georeferenciamento`, `pesquisa_exportar_resultados`, `pesquisa_visualizar_inativas`, `pesquisa_replicar`, `pesquisa_desativar`, `pesquisa_acessa_todas_sem_associacao`, `pesquisa_alteracao_resposta_espontanea`.
- Respostas: `respostas_acesso`, `respostas_alterar`.
- Home: `home_acesso`, `home_visualiza_paineis_superiores`, `home_visualiza_conexoes_recentes`.
- Políticas: `politicas_acesso`.
> (Todos os campos boolean, com `default false`.)

### `InterviewSubmission` (tabela `respostas` / `entrevistas`)
```ts
interface InterviewSubmission {
  id: string;                // PK
  codigoPesquisa: string;
  pesquisaId: string;        // FK -> pesquisas
  pesquisaNome: string;
  pesquisadorId: string;
  pesquisadorNome: string;
  dataHora: string;          // timestamptz
  status: 'concluida' | 'em_andamento' | 'cancelada';
  respostas: AnswerItem[];   // jsonb
  geolocalizacao?: { latitude: number; longitude: number; bairro?: string; cidade?: string };
  audioGravacao?: { duracaoSegundos: number; tamanhoKb: number; nomeArquivo: string; transcricaoTrecho?: string };
  respostasAlteradasPeloAdmin?: boolean;
  historicoEdicao?: { alteradoPor: string; dataHora: string; motivo: string }[];
}
```
```ts
interface AnswerItem { perguntaId: string; perguntaCodigo: string; perguntaEnunciado: string; resposta: string | string[]; }
```

### `MetaTarget` (tabela `metas`)
```ts
interface MetaTarget {
  id: string;          // PK
  pesquisaId: string;  // FK -> pesquisas
  perguntaId: string;
  condicao: 'igual' | 'diferente' | 'contem' | 'maior_que' | 'menor_que';
  resposta: string;
  quantidadeAlvo: number;
  quantidadeAtingida: number;
  ciclo: string;
}
```

### `GlobalDemographicTarget` (tabela `metas_globais`)
```ts
interface GlobalDemographicTarget {
  id: string;               // PK
  pesquisaId: string;       // FK -> pesquisas
  titulo: string;
  descricao?: string;
  criterios: { faixaEtaria?: string; sexo?: string; bairro?: string }; // jsonb
  metaGlobalAlvo: number;
  metaGlobalAtingida: number;
  atribuicoes: { pesquisadorId: string; pesquisadorNome: string; perfilAcessoNome?: string; cotaAlvo: number; cotaAtingida: number; dataAtribuicao: string }[]; // jsonb
  status: 'ativa' | 'concluida' | 'pausada';
  ciclo?: string;
  criadoEm: string;
  atualizadoEm: string;
}
```

### `ActionAuditLog` (tabela `historico_acoes`)
```ts
interface ActionAuditLog {
  id: string;                 // PK
  categoria: 'PESQUISA' | 'RESPOSTA' | 'CONFIGURACAO' | 'SISTEMA';
  tipoAcao: string;           // ex: 'CRIACAO_PESQUISA', 'EDICAO_RESPOSTA', 'NOVA_COLETA', ...
  tituloAcao: string;
  descricaoDetalhada: string;
  autor: { id: string; nome: string; login: string; perfil: string; ip?: string }; // jsonb
  alvo: { tipo: string; id: string; identificador: string; nome?: string };         // jsonb
  alteracoes?: { campo: string; rotulo?: string; valorAnterior?: any; valorNovo?: any }[]; // jsonb
  motivoConformidade?: string;
  timestamp: string;          // timestamptz
  hashIntegridade: string;
  statusConformidade: 'conforme' | 'atencao' | 'critico';
}
```

### `RecentConnection` (tabela `conexoes_recentes`)
```ts
interface RecentConnection {
  id: string;      // PK
  usuario: string;
  perfil: string;
  ip: string;
  dataHora: string;
  navegador: string;
  status: 'sucesso' | 'bloqueado' | 'aviso';
}
```

### `ExternalImport` (tabela `importacoes_externas`)
```ts
interface ExternalImport {
  id: string;            // PK
  nomeArquivo: string;
  pesquisaId: string;    // FK -> pesquisas
  dataImportacao: string;
  totalRegistros: number;
  colunas: string[];     // text[]
  status: 'concluido' | 'processando' | 'erro';
}
```

### Demografia (constantes usadas no helper)
- Faixas etárias: `18 a 25 anos`, `26 a 40 anos`, `41 a 60 anos`, `Acima de 60 anos`.
- Sexo: `M`, `F`, `Outro`.
- Bairros: `Centro`, `Praça da Matriz`, `Zona Norte`, `UBS Central`, e outros conforme a prefeitura.

---

## 4. ENTREGÁVEIS — ESTRUTURA PARA GITHUB

Monte o repositório GitHub com a estrutura de pastas abaixo, adicionando os arquivos de infraestrutura necessários (sem apagar nenhum arquivo existente):

```
dataquest/
├── .github/workflows/ci.yml        # CI: lint + build (TypeScript)
├── .gitignore                      # cobrir node_modules, dist, .env*, .vercel
├── README.md                       # instruções de setup, deploy, variáveis de ambiente
├── .env.example                    # TODAS as variáveis de ambiente documentadas
├── package.json                    # manter scripts atuais + adicionar "typecheck"
├── vite.config.ts
├── tsconfig.json
├── vercel.json                     # configuração de deploy na Vercel
├── server.ts                       # manter (adaptar p/ produção — ver seção 6)
├── supabase/
│   ├── migrations/
│   │   └── 0001_initial_schema.sql # DDL completo + RLS + storage (idempotente)
│   ├── seed.sql                    # dados iniciais: pesquisas padrão, perfis, colaboradores demo
│   └── config.toml                 # configuração do Supabase CLI (projeto, auth, storage)
├── src/
│   ├── ... (TODO o código frontend existente, inalterado)
│   └── services/
│       ├── supabaseSyncService.ts   # manter contrato, refatorar p/ tabelas reais
│       └── (se necessário) supabaseClient.ts
```

**GitHub Actions — `ci.yml`:** ao abrir PR/push na `main`, rode `npm ci`, `npm run lint` (tsc --noEmit) e `npm run build`. Em seguida, para produção, rode `npm run deploy` (ver seção de deploy).

**`.gitignore`:** `node_modules/`, `dist/`, `.env`, `.env.local`, `.env.*.local`, `.vercel`, `*.log`, `.DS_Store`, `server.js`.

---

## 5. ENTREGÁVEIS — SUPABASE (TODAS AS QUERIES)

Gere **um único arquivo SQL** (`supabase/migrations/0001_initial_schema.sql`) completo, comentado e idempotente, com:

### 5.1 Extensões
- `pgcrypto` (para `gen_random_uuid()`), `uuid-ossp` se precisar.

### 5.2 Tabelas (todas com `snake_case`, RLS habilitada, timestamps `timestamptz`)
1. **`perfis_acesso`** — id uuid PK default `gen_random_uuid()`, nome, descricao, permissions jsonb (default `{}`), criado_em, atualizado_em.
2. **`colaboradores`** — id text PK, cpf text UNIQUE, nome, rg, data_nascimento date, sexo text, login text UNIQUE NOT NULL, senha text (hash), perfil_acesso_id uuid FK → perfis_acesso, email, celular, nome_contato_celular, telefone_fixo, nome_contato_fixo, ativo boolean default true, pesquisas_vinculadas_ids text[] default '{}', criado_em. Índices em `login`, `cpf`, `perfil_acesso_id`.
3. **`pesquisas`** — id text PK, codigo text, nome text, descricao text, status text default 'ativa', habilitar_coleta_web boolean default false, tipo_coleta_web text default 'interno', colaborador_web_id text, perguntas jsonb default '[]', regras jsonb default '[]', metas jsonb default '[]', metas_globais jsonb default '[]', pesquisadores_ids text[] default '{}', ciclo_atual int default 1, versao int default 1, criada_em timestamptz default now(), atualizada_em timestamptz default now(), em_andamento boolean default false, server_version int default 1, dados_completos jsonb. Índice em `codigo` e `status`.
4. **`respostas`** — id text PK, codigo_pesquisa, pesquisa_id text FK → pesquisas, pesquisa_nome, pesquisador_id, pesquisador_nome, data_hora timestamptz, status text, respostas jsonb, geolocalizacao jsonb, audio_gravacao jsonb, respostas_alteradas_pelo_admin boolean, historico_edicao jsonb. Índices em `pesquisa_id`, `pesquisador_id`, `data_hora`, `status`. **Índice GIST em `geolocalizacao`** para buscas geoespaciais (se a extensão PostGIS estiver disponível; senão deixe documentado).
5. **`metas`** — id text PK, pesquisa_id FK, pergunta_id, condicao text, resposta text, quantidade_alvo int, quantidade_atingida int default 0, ciclo text. Índice em `pesquisa_id`.
6. **`metas_globais`** — id text PK, pesquisa_id FK, titulo, descricao, criterios jsonb, meta_global_alvo int, meta_global_atingida int default 0, atribuicoes jsonb default '[]', status text default 'ativa', ciclo, criado_em, atualizado_em. Índice em `pesquisa_id`, `status`.
7. **`historico_acoes`** — id text PK, categoria text, tipo_acao text, titulo_acao text, descricao_detalhada text, autor jsonb, alvo jsonb, alteracoes jsonb default '[]', motivo_conformidade text, timestamp timestamptz default now(), hash_integridade text, status_conformidade text default 'conforme'. Índices em `timestamp`, `categoria`, `tipo_acao`, `alvo` (com `alvo->>'id'`).
8. **`conexoes_recentes`** — id text PK, usuario, perfil, ip, data_hora timestamptz, navegador, status.
9. **`importacoes_externas`** — id text PK, nome_arquivo, pesquisa_id FK, data_importacao timestamptz, total_registros int, colunas text[], status.

**Triggers:** em todas as tabelas com `atualizada_em`, crie trigger `set_updated_at` que atualiza `updated_at = now()` em UPDATE.

### 5.3 Queries de CRUD (funções ou exemplos prontos)
Gere funções SQL `SECURITY DEFINER` (ou exemplos de consulta comentados) para:
- `criar_pesquisa`, `atualizar_pesquisa`, `listar_pesquisas`, `buscar_pesquisa_por_id`, `excluir_pesquisa` (soft-delete: setar status='excluida').
- `criar_colaborador`, `autenticar_colaborador` (valida login + hash de senha), `atualizar_senha`, `desativar_colaborador`, `listar_colaboradores`, `buscar_colaborador_por_login`.
- `criar_perfil_acesso`, `atualizar_perfil_acesso`, `listar_perfis`.
- `registrar_resposta` (insert em `respostas`), `listar_respostas_por_pesquisa`, `atualizar_resposta`, `excluir_resposta`, `buscar_resposta_por_id`.
- `criar_meta`, `atualizar_meta`, `calcular_meta_atingida(pesquisa_id, pergunta_id, condicao, resposta)` — função que conta em `respostas` quantos registros batem a condição e atualiza `quantidade_atingida`.
- `criar_meta_global`, `atualizar_meta_global`, `calcular_meta_global(pesquisa_id)` — agrega `respostas` por critérios demográficos (faixa_etaria/sexo/bairro) e atualiza `meta_global_atingida` e as `atribuicoes`.
- `registrar_log_auditoria`, `listar_auditoria(filtros)`, `exportar_auditoria`.
- `registrar_conexao`, `listar_conexoes_recentes`.
- `registrar_importacao`, `listar_importacoes`.

### 5.4 Queries analíticas (dashboard, metas e coleta diária)
Gere VIEWS ou funções que alimentam os painéis existentes (o frontend consome esses números):
- **`view_total_entrevistas_por_pesquisa`** — agrupa `respostas` por `pesquisa_id` e `status='concluida'`.
- **`view_metas_por_pesquisa`** — join `metas` ⇄ `pesquisas` com `quantidade_atingida` e percentual de atingimento.
- **`view_metas_globais_progresso`** — join `metas_globais` ⇄ `pesquisas`, percentual e status.
- **`view_coleta_diaria`** — agrega `respostas` por dia (`date(data_hora)`), contando concluídas/canceladas e pesquisadores ativos distintos; retorna `data`, `total_entrevistas`, `pesquisadores_ativos`, `concluidas`, `canceladas`, `tempo_medio`.
- **`view_progresso_pesquisador`** — para a visão individual de metas por pesquisador: total coletado por `pesquisador_id` × `pesquisa_id`.
- **`view_progresso_demografico`** — agrega `respostas` extraindo `bairro` e faixa etária da `geolocalizacao`/respostas para alimentar `GlobalDemographicTarget`.
- Função **`calcular_atingimento_meta_diaria(pesquisa_id, data)`** — retorna o percentual de atingimento da meta diária (usada no `DailyCollectionMetric`).

### 5.5 Row Level Security (RLS)
Habilite RLS em **todas** as tabelas e crie políticas coerentes com o modelo de login do app (colaboradores com `login`/`senha`):
- Uma função helper `is_authenticated()` que verifica o `auth.uid()` OU um papel customizado (dependendo de como você vincular o login do app ao Supabase Auth).
- Políticas `SELECT/INSERT/UPDATE/DELETE` por função/perfil (ex.: apenas `ADMIN`/`COORDENADOR` alteram `perfis_acesso` e `colaboradores`; todos autenticados leem `pesquisas`; respostas são gerenciadas por quem tem permissão).
- Explique claramente se você usa o **Supabase Auth** (users + JWT) ou uma **tabela de sessão própria**; se usar Auth, mapeie o `auth.uid()` para `colaboradores.id` via uma trigger de sync no `on auth.users` insert.

### 5.6 Auth (Supabase Auth)
- Instrua a ativar o Supabase Auth (email/password) OU a manter o login próprio do app. Se usar Auth, gere o script que sincroniza `auth.users` com `colaboradores`.

### 5.7 Storage (gravação de áudio e importação de planilhas)
- Criar bucket **`audio-gravacoes`** (para `audioGravacao.nomeArquivo`) com políticas RLS (apenas usuários com `pesquisa_ouvir_audio` podem ler; apenas autenticados com permissão de coleta escrevem).
- Criar bucket **`importacoes`** (para planilhas de `ExternalImport`) com políticas de acesso restritas a quem tem `importacao_importar_planilha`.
- Gerar as queries `INSERT INTO storage.buckets ...` e as policies `storage.objects`.

### 5.8 Seed (dados iniciais)
- `supabase/seed.sql` com: os **2 perfis de acesso padrão** (ex.: "Administrador" com todas as permissões true, e "Pesquisador" básico), os **colaboradores demo** (admin e pesquisadores) com senha com hash, e as **pesquisas padrão** do sistema (mesmas do `server.ts`: `pesq_literarraial_2025` = LIT-2025-01, `pesq_saude_2025` = SAU-2025-02, `pesq_transporte_2025`), incluindo perguntas, regras e status `ativa`.

---

## 6. ENTREGÁVEIS — VERCEL (deploy e serverless)

### 6.1 `vercel.json`
Configure a Vercel para servir o frontend e as rotas `/api/*`. Como o app atual tem um backend Express, você deve escolher UMA das duas abordagens (explique e implemente a que você recomenda, mantendo o contrato de API intacto):
- **Opção A (recomendada):** transformar cada rota `/api/*` do `server.ts` em funções serverless Vercel (na pasta `api/`), convertendo o repositório em memória para o Supabase. Mantenha exatamente as mesmas rotas, os mesmos códigos de erro (`428`, `SYNC_REQUIRED_BEFORE_UPLOAD`) e o mesmo formato de resposta. Escreva `api/health.ts`, `api/surveys.ts`, `api/surveys/[id].ts`, `api/surveys/[id]/sync.ts`.
- **Opção B:** se preferir manter o Express, gere um `vercel.json` com `"builds"` apontando para o `server.ts` como função.

Inclua no `vercel.json`: `rewrites` para SPA (todas as rotas `/` caem no `index.html` exceto `/api/*`), `headers` de segurança e o `env` necessário.

### 6.2 Variáveis de ambiente na Vercel
Documente e configure no painel da Vercel:
- `VITE_SUPABASE_URL` — URL do projeto Supabase.
- `VITE_SUPABASE_ANON_KEY` — anon/public key do Supabase.
- `SUPABASE_SERVICE_ROLE_KEY` — chave de service role (usada apenas no backend/serverless, NUNCA no frontend).
- `GEMINI_API_KEY` — chave do Gemini (se usado no serverless).
- `APP_URL` — URL pública da Vercel.

### 6.3 `package.json`
- Manter scripts atuais (`dev`, `build`, `start`, `preview`, `clean`, `lint`).
- Adicionar `"typecheck": "tsc --noEmit"` e `"deploy": "vercel --prod"`.
- Garantir que o build da Vercel seja `npm run build` e o output seja `dist/`.

---

## 7. ARQUIVOS DE CONFIGURAÇÃO GERAIS

Gere/atualize:
- **`.env.example`** — com TODAS as variáveis (Supabase, Gemini, APP_URL) e comentários em português explicando cada uma. Inclua `VITE_SUPABASE_URL=`, `VITE_SUPABASE_ANON_KEY=`, `SUPABASE_SERVICE_ROLE_KEY=`, `GEMINI_API_KEY=`, `APP_URL=`.
- **`supabase/config.toml`** — config do projeto (project_id, api, auth com `enable_signup`, storage buckets).
- **`README.md`** — novo, em português, com: visão geral, stack, como rodar localmente, como configurar Supabase (SQL Editor), como fazer deploy na Vercel, tabela de variáveis de ambiente, e como conectar o GitHub Actions.

---

## 8. ATUALIZAÇÃO DOS SERVIÇOS (manter contrato, trocar a persistência)

- **`src/services/supabaseSyncService.ts`**: mantenha os nomes das funções (`getSupabaseClient`, `isSupabaseConfigured`, `syncSurveyToSupabase`, `syncBatchSurveysToSupabase`) e a tabela `pesquisas`. Adapte apenas para garantir que o upsert funcione com o schema real e registre corretamente os logs de sync.
- Se criar **`src/services/supabaseClient.ts`**, centralize a instância do cliente com as env vars.
- **`server.ts` / rotas serverless**: reescreva a persistência em memória para consultar o Supabase, preservando o fluxo de **sincronização prévia obrigatória com token** (rotas `sync`, `PUT` com exigência de token e erro `428`). Os tokens podem ser guardados em uma tabela auxiliar `sync_tokens` (token, survey_id, expires_at, generated_at, client_version) ou em memória — recomende e implemente a opção com Supabase para persistência real.

---

## 9. CHECKLIST FINAL (confirme ao concluir)

- [ ] Estrutura de pastas GitHub criada sem apagar código existente.
- [ ] `.github/workflows/ci.yml` funcional (lint + build).
- [ ] `supabase/migrations/0001_initial_schema.sql` completo: extensões, 9 tabelas, triggers, índices, RLS, storage, função de login, **todas** as queries CRUD e analíticas, e views de dashboard/metas/coleta.
- [ ] `supabase/seed.sql` com perfis, colaboradores demo e as 3 pesquisas padrão.
- [ ] `vercel.json` + funções serverless `/api/*` com o mesmo contrato e códigos de erro.
- [ ] `.env.example` com todas as variáveis documentadas em português.
- [ ] `README.md` atualizado com passo a passo de deploy.
- [ ] `supabaseSyncService.ts` mantém o contrato e funciona com o schema real.
- [ ] Nenhuma funcionalidade nova foi adicionada; nenhuma entidade/coluna/campo existente foi renomeado.
- [ ] Todas as queries são idempotentes e executáveis no SQL Editor do Supabase.

---

**Instrução final:** entregue cada arquivo em blocos de código completos, com comentários em português, e explique em 3–5 frases como o deploy conecta GitHub → Vercel → Supabase. Ao terminar, liste exatamente quais arquivos foram criados, quais foram alterados, e peça confirmação antes de sugerir qualquer mudança fora do escopo acima.
