// GET /api/collaborators/:id/pesquisas — Pesquisas liberadas para o pesquisador de campo.
//
// Replica, no servidor, a regra de visibilidade centralizada em
// src/utils/researcherUtils.ts (isSurveyVisibleToResearcher):
//   - a pesquisa precisa estar VINCULADA ao colaborador
//     (pesquisas.pesquisadores_ids contém o id do colaborador);
//   - e estar ATIVA (não passou da data_fim); OU
//   - estar CONCLUÍDA pela coordenação, porém RE-HABILITADA para este login
//     (colaboradores.pesquisas_reabilitadas_ids contém a pesquisa).
// Pesquisas excluídas/inativas não aparecem.
//
// É o endpoint que o botão "Sincronizar" da tela de login de campo chama para
// baixar as pesquisas e políticas relacionadas àquele pesquisador.
import type { VercelRequest, VercelResponse } from '@vercel/node';
import { getSupabaseAdmin } from '../../_lib/supabaseAdmin.js';
import { rowToDTO, SurveyRow } from '../../_lib/surveyMapper.js';
import { requireSession, sessionHasPermission } from '../../_lib/session.js';

function isSurveyPassed(row: SurveyRow): boolean {
  if (row.status === 'excluida' || row.status === 'inativa') return true;
  if (!row.data_fim) return false;
  try {
    const end = new Date(row.data_fim);
    end.setHours(23, 59, 59, 999);
    return Date.now() > end.getTime();
  } catch {
    return false;
  }
}

async function getSubmissionsCount(supabase: ReturnType<typeof getSupabaseAdmin>, surveyId: string): Promise<number> {
  const { count } = await supabase
    .from('respostas')
    .select('*', { count: 'exact', head: true })
    .eq('pesquisa_id', surveyId);
  return count ?? 0;
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    return res.status(405).json({ success: false, message: 'Método não permitido.' });
  }

  // F1 — exige sessão e só permite ver as pesquisas do PRÓPRIO colaborador,
  // ou de qualquer um se o perfil tiver acesso a pesquisas/colaboradores.
  const session = requireSession(req, res);
  if (!session) return;

  const { id } = req.query as { id?: string };
  if (!id) {
    return res.status(400).json({ success: false, message: 'Informe o id do colaborador.' });
  }

  const isSelf = session.sub === id;
  const canSeeOthers =
    sessionHasPermission(session, 'pesquisa_acesso') ||
    sessionHasPermission(session, 'colaboradores_acesso');
  if (!isSelf && !canSeeOthers) {
    return res.status(403).json({
      success: false,
      code: 'FORBIDDEN',
      message: 'Você só pode consultar as pesquisas vinculadas ao seu próprio login.',
    });
  }

  try {
    const supabase = getSupabaseAdmin();

    // Busca o colaborador para saber as pesquisas re-habilitadas
    const { data: colab, error: colabErr } = await supabase
      .from('colaboradores')
      .select('id, pesquisas_reabilitadas_ids')
      .eq('id', id)
      .maybeSingle();

    if (colabErr) {
      return res.status(500).json({ success: false, message: `Erro ao consultar colaborador: ${colabErr.message}` });
    }
    if (!colab) {
      return res.status(404).json({ success: false, message: 'Colaborador não encontrado.' });
    }

    const reabilitadas: string[] = colab.pesquisas_reabilitadas_ids || [];

    // FONTE DE VERDADE única: pesquisas.pesquisadores_ids contém o id do pesquisador.
    // (Ao desvincular a pesquisa no sistema base via SurveyForm, ela some daqui.)
    const { data: rows, error: surveysErr } = await supabase
      .from('pesquisas')
      .select('*')
      .contains('pesquisadores_ids', [id]);

    if (surveysErr) {
      return res.status(500).json({ success: false, message: `Erro ao consultar pesquisas: ${surveysErr.message}` });
    }

    const list = [];
    for (const row of (rows || []) as SurveyRow[]) {
      // Regra de visibilidade replicada no servidor
      if (row.status === 'excluida' || row.status === 'inativa') continue;
      if (row.status === 'concluida') {
        if (!reabilitadas.includes(row.id)) continue;
      } else if (row.status === 'ativa') {
        if (isSurveyPassed(row)) continue;
      } else {
        continue;
      }
      const count = await getSubmissionsCount(supabase, row.id);
      list.push(rowToDTO(row, count));
    }

    return res.status(200).json({
      success: true,
      pesquisadorId: id,
      pesquisas: list,
      count: list.length,
    });
  } catch (err: any) {
    return res.status(500).json({
      success: false,
      message: `Falha ao buscar pesquisas do pesquisador: ${err?.message || err}`,
    });
  }
}
