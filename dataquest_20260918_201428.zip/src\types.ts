export type Language = 'pt' | 'en' | 'es';

export type UserRole = 'ADMIN' | 'COORDENADOR' | 'PESQUISADOR' | 'ANALISTA';

export interface AccessPolicyPermissions {
  // Cadastro de Colaboradores
  colaboradores_alterar_senha: boolean;
  colaboradores_desativar: boolean;
  colaboradores_editar: boolean;
  colaboradores_acesso: boolean;
  colaboradores_incluir: boolean;

  // Módulo de Análise de Resultados
  analise_acesso: boolean;
  analise_criar_alterar_excluir_resposta: boolean;

  // Módulo de Importação Externa
  importacao_importar_planilha: boolean;
  importacao_excluir: boolean;
  importacao_acesso: boolean;

  // Módulo de Meta
  meta_criar_alterar_excluir: boolean;
  meta_acesso: boolean;

  // Módulo de Pesquisa
  pesquisa_visualizar_excluidas: boolean;
  pesquisa_acesso: boolean;
  pesquisa_criar: boolean;
  pesquisa_alterar: boolean;
  pesquisa_excluir: boolean;
  pesquisa_ouvir_audio: boolean;
  pesquisa_visualizar_georeferenciamento: boolean;
  pesquisa_exportar_resultados: boolean;
  pesquisa_visualizar_inativas: boolean;
  pesquisa_replicar: boolean;
  pesquisa_desativar: boolean;
  pesquisa_acessa_todas_sem_associacao: boolean;
  pesquisa_alteracao_resposta_espontanea: boolean;

  // Módulo de Visualização de Respostas
  respostas_acesso: boolean;
  respostas_alterar: boolean;

  // Módulo Home
  home_acesso: boolean;
  home_visualiza_paineis_superiores: boolean;
  home_visualiza_conexoes_recentes: boolean;

  // Políticas de Acesso
  politicas_acesso: boolean;

  // Módulo de Relatórios Analíticos
  relatorios_acesso: boolean;
  relatorios_criar_alterar_excluir: boolean;
}

export interface AccessProfile {
  id: string;
  name: string;
  description: string;
  permissions: AccessPolicyPermissions;
}

export interface Collaborator {
  id: string;
  // Dados Pessoais
  cpf: string;
  nome: string;
  rg?: string;
  dataNascimento?: string;
  sexo?: 'M' | 'F' | 'Outro' | '';
  // Dados de Acesso
  login: string;
  senha?: string;
  perfilAcessoId: string;
  email: string;
  // Telefones de Contato
  celular?: string;
  nomeContatoCelular?: string;
  telefoneFixo?: string;
  nomeContatoFixo?: string;
  // Metadados
  ativo: boolean;
  pesquisasVinculadasIds: string[];
  // Pesquisas que, mesmo marcadas como CONCLUÍDAS pela coordenação,
  // foram re-habilitadas especificamente para o login deste pesquisador.
  pesquisasReabilitadasIds?: string[];
  criadoEm: string;
}

export type QuestionType =
  | 'multipla_escolha'
  | 'multipla_selecao'
  | 'texto_aberto'
  | 'escala_numerica'
  | 'nps'
  | 'sim_nao'
  | 'data_hora';

export interface QuestionOption {
  id: string;
  label: string;
  value: string;
  // -------- Personalização visual (Modelo Mobile First Premium) --------
  /** id de um ícone da galeria universal (ver iconLibrary.ts) */
  iconId?: string;
  /** emoji exibido como resposta (galeria de emojis) */
  emoji?: string;
  /** id de um smile oficial (ver smileLibrary.ts) */
  smileId?: string;
  /** imagem (URL ou data URI) exibida como resposta */
  imageUrl?: string;
  /** descrição secundária curta exibida no card */
  description?: string;
  /** cor de destaque específica desta alternativa */
  color?: string;
  /** texto de selo/badge específico desta alternativa */
  badge?: string;
}

/** Modelo de layout de renderização da pesquisa. */
export type SurveyLayoutStyle = 'DEFAULT' | 'CARD' | 'SIDEBAR' | 'MOBILE_PREMIUM';

/** Forma de apresentação das alternativas no modelo Mobile Premium. */
export type AnswerVisualType =
  | 'TEXTO'
  | 'CARDS'
  | 'ICONES'
  | 'SMILEYS'
  | 'IMAGEM'
  | 'EMOJI'
  | 'ESCALA_VISUAL';

/** Tipo de escala visual (smiles/estrelas/corações/polegares/círculos/termômetro). */
export type VisualScaleType =
  | 'emojis'
  | 'estrelas'
  | 'coracoes'
  | 'polegares'
  | 'circulos'
  | 'termometro';

/** Aparência do enunciado da pergunta no modelo Mobile Premium. */
export type QuestionAppearanceType =
  | 'TEXTO'
  | 'TEXTO_ICONE'
  | 'TEXTO_SMILE'
  | 'TEXTO_EMOJI'
  | 'TEXTO_IMAGEM'
  | 'TEXTO_COR'
  | 'TEXTO_BADGE'
  | 'TEXTO_FOTO';

/**
 * Configuração visual de uma pergunta. Todos os campos são opcionais;
 * quando ausentes, o modelo Mobile Premium usa os padrões do tema.
 */
export interface QuestionVisualConfig {
  /** Aparência do enunciado (texto + elemento visual). */
  appearanceType?: QuestionAppearanceType;
  /** Como as alternativas são renderizadas. */
  answerVisualType?: AnswerVisualType;
  /** Ícone do enunciado (id da galeria universal). */
  iconId?: string;
  /** Emoji do enunciado. */
  emoji?: string;
  /** Imagem/foto do enunciado (URL ou data URI). */
  imageUrl?: string;
  /** Texto do selo/badge do enunciado. */
  badge?: string;
  /** Cor de destaque do selo. */
  badgeColor?: string;
  /** Cor de destaque da pergunta (barra/realce). */
  accentColor?: string;
  // ---- Escala visual ----
  /** Tipo de escala visual (quando answerVisualType = ESCALA_VISUAL). */
  scaleType?: VisualScaleType;
  /** Quantidade de níveis (5, 7, 10...). */
  scaleSteps?: number;
  /** Permitir meia estrela / meio coração. */
  scaleAllowHalf?: boolean;
  /** Cores de cada nível dos círculos coloridos. */
  scaleColors?: string[];
  /** Orientação do termômetro. */
  scaleHorizontal?: boolean;
  /** Legenda mínima/máxima da escala. */
  scaleMinLabel?: string;
  scaleMaxLabel?: string;
  // ---- Cores/configuração do card ----
  cardColor?: string;
  iconColor?: string;
  selectionColor?: string;
  buttonColor?: string;
  borderColor?: string;
  borderRadius?: number;
  shadow?: boolean;
  /** Gradiente CSS aplicado ao card (ex: 'linear-gradient(...)'). */
  gradient?: string;
  /** Imagem de fundo do card. */
  backgroundImage?: string;
  // ---- Comentário opcional ----
  commentEnabled?: boolean;
  commentMaxLength?: number;
}

export interface Question {
  id: string;
  codigo: string;
  enunciado: string;
  tipo: QuestionType;
  obrigatoria: boolean;
  opcoes?: QuestionOption[];
  escalaMin?: number;
  escalaMax?: number;
  escalaMinLabel?: string;
  escalaMaxLabel?: string;
  ordem: number;
  iniciarGravacaoAqui?: boolean; // Flag: Iniciar a gravação de áudio a partir desta pergunta
  // -------- Personalização visual (Modelo Mobile First Premium) --------
  /** Bloco completo de configuração visual da pergunta. */
  visual?: QuestionVisualConfig;
  /** Atalhos normalizados (mantidos por compatibilidade com o prompt/DB). */
  questionIcon?: string;
  questionEmoji?: string;
  questionImage?: string;
  answerVisualType?: AnswerVisualType;
  cardColor?: string;
  iconColor?: string;
  badgeColor?: string;
}

export type ConditionOperator = 'igual' | 'diferente' | 'contem' | 'maior_que' | 'menor_que';

export type ConditionActionType =
  | 'saltar_para'
  | 'esconder_pergunta'
  | 'finalizar_formulario';

export interface ConditionalRule {
  id: string;
  perguntaOrigemId: string; // Pergunta analisada
  condicao: ConditionOperator;
  valorComparacao: string; // Respostas conforme condição
  acao: ConditionActionType;
  perguntaDestinoId?: string; // Para saltar ou esconder
  descricao?: string;
}

/** Regra de filtro da "Composição da meta" (Pergunta → Condição → Resposta). */
export interface MetaCompositionRule {
  id: string;
  perguntaId: string;
  perguntaCodigo: string;
  perguntaEnunciado: string;
  condicao: ConditionOperator;
  resposta: string;
}

export interface MetaTarget {
  id: string;
  pesquisaId: string;
  perguntaId: string; // Questão
  condicao: ConditionOperator; // Condição
  resposta: string; // Resposta
  quantidadeAlvo: number;
  quantidadeAtingida: number;
  ciclo: string;
  // Modelo "Composição da meta" (tela de metas)
  nome?: string; // Nome da meta exibido ao pesquisador
  composicao?: MetaCompositionRule[]; // Regras de filtro (Pergunta/Condição/Resposta)
  distribuicao?: 'geral' | 'por_pesquisador'; // Escopo da quantidade de coletas
  quantidadeAlvoPorPesquisador?: number; // Quantidade de coletas por pesquisador
  bloquearAposAtingir?: boolean; // Bloquear coletas após atingir a meta
  status?: 'ativa' | 'pausada' | 'concluida';
  criadoEm?: string;
  atualizadoEm?: string;
}

export type DemographicDimension = 'idade' | 'sexo' | 'bairro';

export interface DemographicQuotaCriteria {
  faixaEtaria?: string; // Ex: '18 a 25 anos', '26 a 40 anos', '41 a 60 anos', 'Acima de 60 anos', 'Todas'
  sexo?: 'M' | 'F' | 'Outro' | 'Todos' | 'Feminino' | 'Masculino';
  escolaridade?: string; // Ex: 'Ensino Fundamental', 'Ensino Médio', 'Ensino Superior', 'Todos'
  bairro?: string; // Ex: 'Centro', 'Praça da Matriz', 'Zona Norte', 'UBS Central', 'Todos'
}

/**
 * Meta base reutilizável do catálogo (sistema base).
 * Define apenas os critérios demográficos e o alvo global; a vinculação de
 * cotas por pesquisador acontece ao montar a pesquisa (Wizard), gerando os
 * GlobalDemographicTarget da pesquisa.
 */
export interface BaseMeta {
  id: string;
  titulo: string;
  descricao?: string;
  criterios: DemographicQuotaCriteria;
  metaGlobalAlvo: number;
  status: 'ativa' | 'concluida' | 'pausada';
  criadoEm: string;
  atualizadoEm: string;
}

export interface ResearcherQuotaAssignment {
  pesquisadorId: string;
  pesquisadorNome: string;
  perfilAcessoNome?: string;
  cotaAlvo: number; // Quantidade atribuída especificamente a esse pesquisador
  cotaAtingida: number; // Quantidade realizada em tempo real por esse pesquisador
  dataAtribuicao: string;
}

export interface GlobalDemographicTarget {
  id: string;
  /** Referência à meta base do catálogo que originou esta meta (opcional). */
  baseMetaId?: string;
  pesquisaId: string;
  titulo: string; // Ex: "Amostragem Jovens - Praça da Matriz", "Cota Feminina Geral"
  descricao?: string;
  criterios: DemographicQuotaCriteria;
  metaGlobalAlvo: number; // Meta total somada ou alvo geral da pesquisa
  metaGlobalAtingida: number; // Total coletado em tempo real em toda a pesquisa
  atribuicoes: ResearcherQuotaAssignment[]; // Vínculo com perfis/pesquisadores específicos
  status: 'ativa' | 'concluida' | 'pausada';
  ciclo?: string;
  criadoEm: string;
  atualizadoEm: string;
}

export interface Survey {
  id: string;
  codigo: string;
  nome: string; // ex: "LiterArraial 2025 - Prefeitura"
  descricao: string;
  status: 'ativa' | 'inativa' | 'concluida' | 'excluida';
  habilitarColetaWeb: boolean;
  tipoColetaWeb: 'publico' | 'interno';
  colaboradorWebId?: string; // Pesquisador atribuído para registros web
  perguntas: Question[];
  regras: ConditionalRule[];
  metas: MetaTarget[];
  metasGlobais?: GlobalDemographicTarget[]; // Gerenciamento de Metas Globais por Demografia
  pesquisadoresIds: string[]; // Pesquisadores que irão participar
  cicloAtual: number;
  versao: number;
  criadaEm: string;
  atualizadaEm: string;
  dataInicio?: string; // Data de início do campo (YYYY-MM-DD)
  dataFim?: string; // Data limite/término do campo (YYYY-MM-DD)
  // Plano Amostral e Dimensionamento de Equipe em Campo
  metaTotalColetas?: number; // Meta total estabelecida de coletas (amostra total N)
  nivelConfiancaPercentual?: number; // Nível/margem de confiança (padrão: 95%)
  margemErroPercentual?: number; // Margem de erro máxima aceitável (padrão: ±3.5%)
  populacaoUniverso?: number; // População total finita (universo amostral, opcional)
  metaSexoMasculino?: number; // Quota de sexo masculino (soma com feminino = total de coletas)
  metaSexoFeminino?: number; // Quota de sexo feminino (soma com masculino = total de coletas)
  metaSexoOutro?: number; // Quota de sexo outro/não binário
  diasPrevistosCampo?: number; // Dias úteis estimados para o trabalho de campo (padrão: 3 a 5)
  mediaColetasDiaPesquisador?: number; // Capacidade média diária por pesquisador (padrão: 15 entrevistas/dia)
  reservaTecnicaPercentual?: number; // Margem de segurança de amostragem (padrão: 15%)
  // Configurações de Gravação de Áudio de Campo
  habilitarGravacaoAudio?: boolean; // Padrão true
  gravarAudioAPartirPerguntaId?: string; // ID da pergunta a partir de onde será gravada (se vazio, grava desde o início)
  tempoLimiteGravacaoMinutos?: number; // Padrão: 2 minutos quando não especificado, máximo 10 minutos (1 a 10 min)
  // Campos de Sincronização com o Servidor Central
  emAndamento?: boolean; // Indica se a pesquisa está em andamento (coletando dados / em campo)
  serverVersion?: number; // Versão persistida no servidor
  serverSyncToken?: string; // Token de pré-sincronização emitido pelo servidor para autorizar upload
  lastServerSyncAt?: string; // Carimbo da última sincronização prévia com o servidor
  serverSyncStatus?: 'sincronizado' | 'necessita_sincronizacao' | 'sincronizando' | 'autorizado_para_subir' | 'erro_conflito';
  totalEntrevistasColetadas?: number; // Total de coletas vinculadas no servidor
  // ===================================================================
  // Modelo Mobile First Premium (Opção 6) — aparência/identidade da pesquisa
  // Campo layoutStyle seleciona o renderizador. DEFAULT/CARD/SIDEBAR mantêm
  // exatamente o comportamento atual; MOBILE_PREMIUM ativa a nova interface.
  // ===================================================================
  layoutStyle?: SurveyLayoutStyle;
  /** Nome exibido da instituição (cabeçalho do modelo premium). */
  institutionName?: string;
  /** Logo da instituição (URL ou data URI). */
  logoImage?: string;
  /** Imagem de capa da tela inicial. */
  coverImage?: string;
  /** Imagem da tela final. */
  finishImage?: string;
  /** Mensagem de boas-vindas da capa. */
  welcomeMessage?: string;
  /** Mensagem final de agradecimento. */
  finishMessage?: string;
  /** Mensagem institucional (ex: Prefeitura) exibida no fim. */
  prefeituraMessage?: string;
  /** QR Code opcional exibido na tela final. */
  qrCodeUrl?: string;
  /** Cor principal do tema (padrão azul institucional GIDE). */
  themeAccent?: string;
  /** Cor secundária do tema. */
  themeSecondary?: string;
  /** Exibe a barra de progresso em percentual. */
  showProgressPercent?: boolean;
  /** Exibe indicador 'Pergunta X de Y'. */
  showQuestionIndicator?: boolean;
  /** Rótulo do botão de início da capa. */
  startButtonLabel?: string;
}

export interface ServerSyncCheckResult {
  success: boolean;
  emAndamento: boolean;
  serverVersion: number;
  syncToken?: string;
  expiresAt?: string;
  submissionsCount: number;
  message: string;
  divergences?: string[];
  serverSurvey?: Survey;
}

/**
 * Bloco livre de um Relatório Analítico. O usuário monta quantos blocos
 * quiser, cada um com seu próprio título; "origem" só existe para fins de
 * exibição (ícone/rótulo de "gerado automaticamente"), nunca restringe o
 * conteúdo ou a estrutura do relatório.
 */
export interface ReportBlock {
  id: string;
  titulo: string;
  conteudo: string; // texto livre (markdown simples: **negrito**, listas com "- ")
  ordem: number;
  origem: 'automatico_quantitativo' | 'automatico_qualitativo' | 'manual';
  criadoEm: string;
  atualizadoEm: string;
}

export interface AnalyticalReport {
  id: string;
  pesquisaId: string;
  pesquisaNome: string;
  titulo: string;
  blocos: ReportBlock[];
  criadoPorId: string;
  criadoPorNome: string;
  criadoEm: string;
  atualizadoEm: string;
}

export interface AnswerItem {
  perguntaId: string;
  perguntaCodigo: string;
  perguntaEnunciado: string;
  resposta: string | string[];
  /** Comentário opcional do entrevistado (Modelo Mobile Premium). */
  comentario?: string;
}

export interface InterviewSubmission {
  id: string;
  codigoPesquisa: string;
  pesquisaId: string;
  pesquisaNome: string;
  pesquisadorId: string;
  pesquisadorNome: string;
  dataHora: string; // ISO format
  status: 'concluida' | 'em_andamento' | 'cancelada';
  respostas: AnswerItem[];
  // Detalhes extras de campo
  geolocalizacao?: {
    latitude: number;
    longitude: number;
    bairro?: string;
    cidade?: string;
  };
  audioGravacao?: {
    duracaoSegundos: number;
    tamanhoKb: number;
    nomeArquivo: string;
    transcricaoTrecho?: string;
    audioUrl?: string; // Data URL ou Blob URL para reprodução e exportação
    iniciouNaPerguntaCodigo?: string; // Código da pergunta onde a gravação foi iniciada
    tempoConfiguradoMinutos?: number; // Tempo máximo configurado (padrão 2 min, máx 10 min)
  };
  respostasAlteradasPeloAdmin?: boolean;
  historicoEdicao?: {
    alteradoPor: string;
    dataHora: string;
    motivo: string;
  }[];
}

export interface RecentConnection {
  id: string;
  usuario: string;
  perfil: string;
  ip: string;
  dataHora: string;
  navegador: string;
  status: 'sucesso' | 'bloqueado' | 'aviso';
}

export interface ExternalImport {
  id: string;
  nomeArquivo: string;
  pesquisaId: string;
  dataImportacao: string;
  totalRegistros: number;
  colunas: string[];
  status: 'concluido' | 'processando' | 'erro';
}

export type ActionCategory = 'PESQUISA' | 'RESPOSTA' | 'CONFIGURACAO' | 'SISTEMA';

export type ActionType =
  | 'CRIACAO_PESQUISA'
  | 'EDICAO_PESQUISA'
  | 'STATUS_PESQUISA'
  | 'REPLICACAO_PESQUISA'
  | 'EXCLUSAO_PESQUISA'
  | 'RESTAURACAO_PESQUISA'
  | 'EDICAO_RESPOSTA'
  | 'EXCLUSAO_RESPOSTA'
  | 'NOVA_COLETA'
  | 'ALTERACAO_META'
  | 'IMPORTACAO_DADOS'
  | 'ACAO_EM_LOTE'
  | 'SINCRONIZACAO_OFFLINE'
  | 'CRIACAO_RELATORIO'
  | 'EDICAO_RELATORIO'
  | 'EXCLUSAO_RELATORIO';

export interface FieldChange {
  campo: string;
  rotulo?: string;
  valorAnterior?: string | number | boolean | null;
  valorNovo?: string | number | boolean | null;
}

export interface ActionAuditLog {
  id: string;
  categoria: ActionCategory;
  tipoAcao: ActionType;
  tituloAcao: string;
  descricaoDetalhada: string;
  // Quem
  autor: {
    id: string;
    nome: string;
    login: string;
    perfil: string;
    ip?: string;
  };
  // O quê
  alvo: {
    tipo: 'pesquisa' | 'resposta' | 'meta' | 'importacao' | 'sistema' | 'colaborador' | 'relatorio';
    id: string;
    identificador: string;
    nome?: string;
  };
  alteracoes?: FieldChange[];
  motivoConformidade?: string;
  // Quando
  timestamp: string;
  // Conformidade
  hashIntegridade: string;
  statusConformidade: 'conforme' | 'atencao' | 'critico';
}

export interface OfflineSyncItem {
  id: string;
  tipo: 'PESQUISA_SALVA' | 'RESPOSTA_COLETA';
  titulo: string;
  resumo: string;
  dataCriacao: string;
  status: 'pendente' | 'sincronizando' | 'sincronizado' | 'erro';
  payload: any;
  erroMensagem?: string;
}

export interface DailyCollectionMetric {
  dataIso: string; // YYYY-MM-DD
  dataFormatada: string; // DD/MM/YYYY
  diaSemana: string; // Seg, Ter, Qua, etc.
  totalEntrevistas: number;
  pesquisadoresAtivos: string[];
  tempoMedioMinutos: number;
  metaDiaria: number;
  atingimentoPercentual: number;
  concluidas: number;
  canceladas: number;
}

export interface SyncProgressItem {
  id: string;
  nome: string;
  codigo: string;
  status: 'pending' | 'syncing' | 'success' | 'failed';
  error?: string;
}

export interface SyncProgressState {
  isActive: boolean;
  phase: 'idle' | 'detecting' | 'syncing' | 'completed' | 'error';
  current: number;
  total: number;
  currentSurveyName?: string;
  percent: number;
  message: string;
  mode?: 'live' | 'simulated';
  startedAt?: string;
  completedAt?: string;
  failedCount?: number;
  syncedItems: SyncProgressItem[];
}
